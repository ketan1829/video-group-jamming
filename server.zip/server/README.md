# Video-Group-Meeting-Server

- Node Express
- Socket.io

## Installation
<pre>
  <code>
    /* Install */
    npm install
    
    /* Run */
    npm run dev
  </code>
</pre>