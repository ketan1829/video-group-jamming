# Video-Group-Meeting-Client

- React
- WebRTC

## Installation
<pre>
  <code>
    /* Install */
    npm install
    
    /* Run */
    npm start
  </code>
</pre>