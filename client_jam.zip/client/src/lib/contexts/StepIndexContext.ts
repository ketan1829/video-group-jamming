import React from 'react';

export const StepIndexContext = React.createContext(null);
