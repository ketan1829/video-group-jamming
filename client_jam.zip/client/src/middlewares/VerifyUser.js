function verifyUserName(){


}